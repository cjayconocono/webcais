  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">

    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">

      

      <!-- Sidebar Menu -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">DASHBOARD</li>
        <!-- Optionally, you can add icons to the links -->
        <li><a href="A_book.php"><i class="fa fa-book"></i> <span>BOOK</span></a></li>
        <li><a href="A_student_list.php"><i class="fa fa-pencil-square-o"></i> <span>STUDENT LIST</span></a></li>

        <li><a href="A_logs.php"><i class="fa fa-map-pin"></i> <span>HISTORY LOGS</span></a></li>


        <li><a href="A_manage.php"><i class="fa fa-users"></i> <span>MANAGE ACCOUNTS</span></a></li>

        <li><a href="A_notice.php"><i class="fa fa-info-circle"></i> <span>NOTICE</span></a></li>
        
      </ul>
      <!-- /.sidebar-menu -->
    </section>
    <!-- /.sidebar -->
  </aside>