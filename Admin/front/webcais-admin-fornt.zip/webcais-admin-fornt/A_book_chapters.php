<!DOCTYPE html>
<!--
This is a starter template page. Use this page to start your new project from
scratch. This page gets rid of all links and provides the needed markup only.
-->
<html>
<head>
 <?php include("admin_header.php"); ?>
<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php include("admin_header.php"); ?>
<?php include("admin_sidebar.php"); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <section class="content container-fluid">

  
<center><h1>BOOK 1 CHAPTERS</h1></center>

<div class="col-md-12">
  <div class="row">
<button class="btn btn-success" style="width: 1100px;"><i class="fa fa-info"></i> &nbsp; Chapter 1. &nbsp; Sample Chapter</button> <p></p>

<button class="btn btn-success" style="width: 1100px;"><i class="fa fa-info"></i> &nbsp; Chapter 2. &nbsp; Sample Chapter</button> <p></p>
<button class="btn btn-success" style="width: 1100px;"><i class="fa fa-info"></i> &nbsp; Chapter 3. &nbsp; Sample Chapter</button> <p></p>
<button class="btn btn-success" style="width: 1100px;"><i class="fa fa-info"></i> &nbsp; Chapter 4. &nbsp; Sample Chapter</button> <p></p>
<button class="btn btn-success" style="width: 1100px;"><i class="fa fa-info"></i>  &nbsp;Chapter 5. &nbsp; Sample Chapter</button> <p></p>


</div>
</div>












    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

 
<!-- REQUIRED JS SCRIPTS -->
<?php include("admin_footer.php"); ?>
</div>
<!-- ./wrapper -->
<?php include("admin_scripts.php"); ?>
</body>
</html> 